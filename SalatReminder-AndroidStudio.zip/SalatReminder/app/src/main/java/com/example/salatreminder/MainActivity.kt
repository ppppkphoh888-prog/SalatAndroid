package com.example.salatreminder

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_NOTIFICATIONS = 100
        private const val REQUEST_RINGTONE = 101
        const val PREFS = "salat_reminder_settings"
        const val KEY_INTERVAL = "interval_ms"
        const val KEY_SOUND_MODE = "sound_mode"
        const val KEY_RINGTONE_URI = "ringtone_uri"
        const val KEY_FORMAT = "format"
        const val KEY_CUSTOM_TEXT = "custom_text"
        const val KEY_VIBRATE = "vibrate"
        const val KEY_AMPLITUDE = "amplitude"
        const val SOUND_TONE = "tone"
        const val SOUND_SILENT = "silent"

        val INTERVALS = longArrayOf(
            10_000L, 20_000L, 30_000L, 60_000L, 120_000L,
            300_000L, 600_000L, 1_200_000L, 1_800_000L, 3_600_000L
        )
        val INTERVAL_LABELS = arrayOf(
            "١٠ ثواني", "٢٠ ثانية", "٣٠ ثانية", "دقيقة", "دقيقتين",
            "٥ دقائق", "١٠ دقائق", "ثلث ساعة", "نصف ساعة", "ساعة"
        )
        val FORMATS = arrayOf(
            "اللهم صلِّ وسلِّم على سيدنا محمد",
            "اللهم صلِّ على محمد وعلى آل محمد",
            "اللهم صلِّ وسلِّم وبارك على سيدنا محمد",
            "صلى الله عليه وسلم",
            "نص مخصص"
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var intervalSpinner: Spinner
    private lateinit var formatGroup: RadioGroup
    private lateinit var customText: EditText
    private lateinit var preview: TextView
    private lateinit var soundGroup: RadioGroup
    private lateinit var vibrationSeek: SeekBar
    private lateinit var vibrationStatus: TextView
    private lateinit var vibrationSwitch: android.widget.Switch
    private lateinit var mainButton: Button
    private var selectedRingtone: Uri? = null
    private var testRingtone: Ringtone? = null
    private var serviceRunning = false
    private var suppressCallbacks = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        selectedRingtone = prefs.getString(KEY_RINGTONE_URI, null)?.let(Uri::parse)
        serviceRunning = isReminderServiceRunning()
        buildScreen()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        serviceRunning = isReminderServiceRunning()
        if (::mainButton.isInitialized) updateMainButton()
    }

    private fun buildScreen() {
        val scroll = android.widget.ScrollView(this).apply {
            setBackgroundColor(0xFF0B2A21.toInt())
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(content)
        setContentView(scroll)

        val heading = TextView(this).apply {
            text = "الصلاة على النبي ﷺ"
            textSize = 27f
            setTextColor(0xFFD9B25A.toInt())
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(heading, matchWrap())
        addText(content, "تذكير متكرر بالصلاة والسلام على رسول الله ﷺ", 15f, true)
        addSection(content, "مدة التذكير")
        intervalSpinner = Spinner(this)
        intervalSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, INTERVAL_LABELS
        )
        content.addView(intervalSpinner, matchWrap())
        val savedInterval = prefs.getLong(KEY_INTERVAL, 60_000L)
        intervalSpinner.setSelection(INTERVALS.indexOf(savedInterval).let { if (it < 0) 3 else it })
        intervalSpinner.onItemSelectedListener = SimpleItemSelectedListener {
            if (!suppressCallbacks) saveAndUpdate(KEY_INTERVAL, INTERVALS[it])
        }

        addSection(content, "صيغة الصلاة")
        formatGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        FORMATS.forEachIndexed { index, text ->
            val radio = RadioButton(this).apply {
                id = 2000 + index
                this.text = text
                textSize = 15f
                setTextColor(0xFFF4F0E6.toInt())
                buttonTintList = android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt())
            }
            formatGroup.addView(radio)
        }
        content.addView(formatGroup, matchWrap())
        customText = EditText(this).apply {
            hint = "اكتب صيغة الصلاة التي تريدها"
            setHintTextColor(0xFFB6C4BD.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt()))
            textSize = 15f
            setSingleLine(false)
            minLines = 2
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        content.addView(customText, matchWrap())
        customText.setText(prefs.getString(KEY_CUSTOM_TEXT, "اللهم صلِّ وسلِّم على سيدنا محمد"))
        val savedFormat = prefs.getInt(KEY_FORMAT, 0).coerceIn(0, 4)
        formatGroup.check(2000 + savedFormat)
        formatGroup.setOnCheckedChangeListener { _, checkedId ->
            if (!suppressCallbacks) {
                val index = (checkedId - 2000).coerceIn(0, 4)
                prefs.edit().putInt(KEY_FORMAT, index).apply()
                updatePreviewAndService()
            }
        }
        customText.addTextChangedListener(SimpleTextWatcher {
            if (!suppressCallbacks) {
                prefs.edit().putString(KEY_CUSTOM_TEXT, it).apply()
                updatePreviewAndService()
            }
        })
        preview = TextView(this).apply {
            textSize = 16f
            setTextColor(0xFFD9B25A.toInt())
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFF12382C.toInt())
        }
        content.addView(preview, matchWrap())
        updatePreview()

        addSection(content, "الصوت")
        soundGroup = RadioGroup(this).apply {
            orientation = RadioGroup.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val tone = makeRadio("نغمة", 3001)
        val silent = makeRadio("صامت", 3002)
        soundGroup.addView(tone)
        soundGroup.addView(silent)
        content.addView(soundGroup, matchWrap())
        soundGroup.check(if (prefs.getString(KEY_SOUND_MODE, SOUND_TONE) == SOUND_SILENT) 3002 else 3001)
        soundGroup.setOnCheckedChangeListener { _, checked ->
            if (!suppressCallbacks) {
                val mode = if (checked == 3002) SOUND_SILENT else SOUND_TONE
                prefs.edit().putString(KEY_SOUND_MODE, mode).apply()
                notifyServiceUpdate()
            }
        }
        val ringtoneButton = makeButton("اختيار نغمة الإشعار")
        content.addView(ringtoneButton, matchWrap())
        ringtoneButton.setOnClickListener { openRingtonePicker() }
        val testSoundButton = makeButton("تجربة الصوت")
        content.addView(testSoundButton, matchWrap())
        testSoundButton.setOnClickListener { playTestSound() }

        addSection(content, "الاهتزاز")
        vibrationSwitch = android.widget.Switch(this).apply {
            text = "تشغيل الاهتزاز مع التذكير"
            textSize = 15f
            setTextColor(0xFFF4F0E6.toInt())
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt())
            isChecked = prefs.getBoolean(KEY_VIBRATE, true)
        }
        content.addView(vibrationSwitch, matchWrap())
        vibrationSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_VIBRATE, checked).apply()
            notifyServiceUpdate()
        }
        addText(content, "قوة الاهتزاز: ١٪ إلى ١٠٠٪", 14f, false)
        vibrationSeek = SeekBar(this).apply {
            max = 99
            progress = (prefs.getInt(KEY_AMPLITUDE, 60) - 1).coerceIn(0, 99)
            progressTintList = android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt())
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt())
        }
        content.addView(vibrationSeek, matchWrap())
        vibrationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val percent = progress + 1
                prefs.edit().putInt(KEY_AMPLITUDE, percent).apply()
                vibrationStatus.text = "القوة المختارة: $percent٪"
                notifyServiceUpdate()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        vibrationStatus = TextView(this).apply {
            setTextColor(0xFFCFD9D3.toInt())
            textSize = 13f
        }
        content.addView(vibrationStatus, matchWrap())
        updateVibrationCapability()
        val testVibration = makeButton("تجربة الاهتزاز")
        content.addView(testVibration, matchWrap())
        testVibration.setOnClickListener { vibrateOnce() }

        addSection(content, "تشغيل التذكير")
        mainButton = makeButton("")
        mainButton.textSize = 18f
        content.addView(mainButton, matchWrap())
        mainButton.setOnClickListener { toggleService() }

        val notificationButton = makeButton("السماح بالإشعارات")
        content.addView(notificationButton, matchWrap())
        notificationButton.setOnClickListener { requestNotificationPermissionIfNeeded(force = true) }

        val batteryButton = makeButton("فتح إعداد استثناء تحسين البطارية")
        content.addView(batteryButton, matchWrap())
        batteryButton.setOnClickListener { requestBatteryExemption() }

        addText(
            content,
            "على أجهزة Samsung: الإعدادات ← البطارية ← حدود استخدام الخلفية، واجعل التطبيق «غير مقيّد» وأخرجه من «التطبيقات النائمة» و«التطبيقات في وضع السكون العميق».",
            13f,
            false
        )
        updateMainButton()
    }

    private fun updateVibrationCapability() {
        val vibrator = getVibrator()
        val supports = Build.VERSION.SDK_INT >= 26 && vibrator?.hasAmplitudeControl() == true
        vibrationStatus.text = if (supports) {
            "القوة المختارة: ${prefs.getInt(KEY_AMPLITUDE, 60)}٪ — جهازك يدعم التحكم بالقوة."
        } else {
            "جهازك لا يدعم التحكم بدرجة القوة؛ سيُستخدم الاهتزاز العادي."
        }
    }

    private fun updatePreview() {
        if (!::preview.isInitialized) return
        preview.text = "معاينة الإشعار:\n${currentSalawatText()}"
    }

    private fun currentSalawatText(): String {
        val index = prefs.getInt(KEY_FORMAT, 0).coerceIn(0, 4)
        return if (index == 4) {
            prefs.getString(KEY_CUSTOM_TEXT, "").orEmpty().ifBlank { "اللهم صلِّ وسلِّم على سيدنا محمد" }
        } else FORMATS[index]
    }

    private fun updatePreviewAndService() {
        updatePreview()
        notifyServiceUpdate()
    }

    private fun saveAndUpdate(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
        notifyServiceUpdate()
    }

    private fun notifyServiceUpdate() {
        if (serviceRunning) {
            startService(Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_UPDATE))
        }
    }

    private fun toggleService() {
        if (serviceRunning) {
            startService(Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_STOP))
            serviceRunning = false
            updateMainButton()
        } else {
            requestNotificationPermissionIfNeeded()
            val intent = Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_START)
            ContextCompat.startForegroundService(this, intent)
            serviceRunning = true
            updateMainButton()
        }
    }

    private fun updateMainButton() {
        if (::mainButton.isInitialized) {
            mainButton.text = if (serviceRunning) "إيقاف التذكير" else "تشغيل التذكير"
            mainButton.setBackgroundColor(if (serviceRunning) 0xFF8C3932.toInt() else 0xFFD9B25A.toInt())
            mainButton.setTextColor(if (serviceRunning) 0xFFFFFFFF.toInt() else 0xFF0B2A21.toInt())
        }
    }

    private fun requestNotificationPermissionIfNeeded(force: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            if (force || !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
            }
        }
    }

    private fun openRingtonePicker() {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر نغمة الإشعار")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, selectedRingtone)
        }
        startActivityForResult(intent, REQUEST_RINGTONE)
    }

    @Deprecated("The system ringtone picker returns its result through this activity callback.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_RINGTONE && resultCode == RESULT_OK) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (uri != null) {
                selectedRingtone = uri
                prefs.edit().putString(KEY_RINGTONE_URI, uri.toString()).apply()
                try {
                    val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    if (flags != 0) contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                    // Many system ringtone providers expose stable URIs without a persistable grant.
                }
                Toast.makeText(this, "تم حفظ النغمة", Toast.LENGTH_SHORT).show()
                notifyServiceUpdate()
            }
        }
    }

    private fun playTestSound() {
        if (prefs.getString(KEY_SOUND_MODE, SOUND_TONE) == SOUND_SILENT) {
            Toast.makeText(this, "الوضع الصامت مفعّل", Toast.LENGTH_SHORT).show()
            return
        }
        stopTestRingtone()
        val uri = selectedRingtone ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        testRingtone = RingtoneManager.getRingtone(this, uri)
        testRingtone?.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        testRingtone?.play()
    }

    private fun stopTestRingtone() {
        try { testRingtone?.stop() } catch (_: Exception) {}
        testRingtone = null
    }

    private fun vibrateOnce() {
        val vibrator = getVibrator() ?: return
        val percent = prefs.getInt(KEY_AMPLITUDE, 60)
        if (Build.VERSION.SDK_INT >= 26 && vibrator.hasAmplitudeControl()) {
            val amplitude = (1 + (percent - 1) * 254 / 99).coerceIn(1, 255)
            vibrator.vibrate(VibrationEffect.createWaveform(
                longArrayOf(0, 350, 120, 350),
                intArrayOf(0, amplitude, 0, amplitude),
                -1
            ))
        } else if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 350, 120, 350), -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(700)
        }
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun requestBatteryExemption() {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    private fun isReminderServiceRunning(): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        @Suppress("DEPRECATION")
        return manager.getRunningServices(Int.MAX_VALUE).any { it.service.className == ReminderService::class.java.name }
    }

    private fun makeRadio(label: String, idValue: Int) = RadioButton(this).apply {
        id = idValue
        text = label
        textSize = 15f
        setTextColor(0xFFF4F0E6.toInt())
        buttonTintList = android.content.res.ColorStateList.valueOf(0xFFD9B25A.toInt())
    }

    private fun addSection(parent: LinearLayout, text: String) {
        val label = TextView(this).apply {
            this.text = text
            textSize = 19f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFD9B25A.toInt())
            setPadding(0, dp(22), 0, dp(8))
            gravity = Gravity.RIGHT
        }
        parent.addView(label, matchWrap())
    }

    private fun addText(parent: LinearLayout, text: String, size: Float, centered: Boolean) {
        val view = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFE8EEE9.toInt())
            gravity = if (centered) Gravity.CENTER else Gravity.RIGHT
            setPadding(0, dp(8), 0, dp(8))
        }
        parent.addView(view, matchWrap())
    }

    private fun makeButton(label: String) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setTextColor(0xFF0B2A21.toInt())
        setBackgroundColor(0xFFD9B25A.toInt())
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(5) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        stopTestRingtone()
        super.onDestroy()
    }
}

private class SimpleItemSelectedListener(
    private val callback: (Int) -> Unit
) : android.widget.AdapterView.OnItemSelectedListener {
    override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
        callback(position)
    }
    override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
}

private class SimpleTextWatcher(
    private val callback: (String) -> Unit
) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { callback(s?.toString().orEmpty()) }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
