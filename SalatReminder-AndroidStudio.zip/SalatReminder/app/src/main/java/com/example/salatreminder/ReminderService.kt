package com.example.salatreminder

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat

class ReminderService : Service() {

    companion object {
        const val ACTION_START = "com.example.salatreminder.START"
        const val ACTION_UPDATE = "com.example.salatreminder.UPDATE"
        const val ACTION_STOP = "com.example.salatreminder.STOP"
        private const val CHANNEL_ID = "salawat_reminders"
        private const val FOREGROUND_ID = 4101
        private const val REMINDER_ID = 4102
    }

    private val handler = Handler(Looper.getMainLooper())
    private var wakeLock: PowerManager.WakeLock? = null
    private var reminderCount = 0
    private var reminderRunnable: Runnable? = null
    private var ringtone: Ringtone? = null
    private var isStarted = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                if (!isStarted) startAsForeground()
                updateSchedule()
                updateForegroundNotification()
            }
            else -> {
                if (!isStarted) startAsForeground()
                updateSchedule()
            }
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val notification = buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(
                FOREGROUND_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(FOREGROUND_ID, notification)
        }
        isStarted = true
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:SalawatReminder")
        wakeLock?.setReferenceCounted(false)
        if (wakeLock?.isHeld != true) wakeLock?.acquire()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تذكيرات الصلاة على النبي ﷺ",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات التذكير بالصلاة والسلام على النبي ﷺ"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val stopIntent = Intent(this, ReminderService::class.java).setAction(ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this, 41, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this, 42, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("الصلاة على النبي ﷺ")
            .setContentText("التذكير يعمل — عدد التذكيرات: $reminderCount")
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPendingIntent)
            .build()
    }

    private fun updateForegroundNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(FOREGROUND_ID, buildForegroundNotification())
    }

    private fun updateSchedule() {
        reminderRunnable?.let(handler::removeCallbacks)
        val delay = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getLong(MainActivity.KEY_INTERVAL, 60_000L)
            .coerceAtLeast(1_000L)
        reminderRunnable = Runnable {
            sendReminder()
            updateForegroundNotification()
            updateSchedule()
        }
        handler.postDelayed(reminderRunnable!!, delay)
    }

    private fun sendReminder() {
        reminderCount++
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val formatIndex = prefs.getInt(MainActivity.KEY_FORMAT, 0).coerceIn(0, 4)
        val message = if (formatIndex == 4) {
            prefs.getString(MainActivity.KEY_CUSTOM_TEXT, "").orEmpty()
                .ifBlank { "اللهم صلِّ وسلِّم على سيدنا محمد" }
        } else {
            MainActivity.FORMATS[formatIndex]
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("الصلاة على النبي ﷺ")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setTimeoutAfter(6_000L)
            .build()

        getSystemService(NotificationManager::class.java).notify(REMINDER_ID, notification)
        playConfiguredSound(prefs)
        vibrateIfEnabled(prefs)
    }

    private fun playConfiguredSound(prefs: android.content.SharedPreferences) {
        if (prefs.getString(MainActivity.KEY_SOUND_MODE, MainActivity.SOUND_TONE) != MainActivity.SOUND_TONE) return
        stopRingtone()
        val saved = prefs.getString(MainActivity.KEY_RINGTONE_URI, null)
        val uri = saved?.let(Uri::parse) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        try {
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            ringtone?.play()
        } catch (_: Exception) {
            stopRingtone()
        }
    }

    private fun stopRingtone() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
    }

    private fun vibrateIfEnabled(prefs: android.content.SharedPreferences) {
        if (!prefs.getBoolean(MainActivity.KEY_VIBRATE, true)) return
        val vibrator = getVibrator() ?: return
        val percent = prefs.getInt(MainActivity.KEY_AMPLITUDE, 60).coerceIn(1, 100)
        try {
            if (Build.VERSION.SDK_INT >= 26 && vibrator.hasAmplitudeControl()) {
                val amplitude = (1 + (percent - 1) * 254 / 99).coerceIn(1, 255)
                vibrator.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0, 350, 120, 350),
                        intArrayOf(0, amplitude, 0, amplitude),
                        -1
                    )
                )
            } else if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 350, 120, 350), -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(700)
            }
        } catch (_: SecurityException) {
        }
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    override fun onDestroy() {
        reminderRunnable?.let(handler::removeCallbacks)
        stopRingtone()
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
        getSystemService(NotificationManager::class.java).cancel(REMINDER_ID)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
