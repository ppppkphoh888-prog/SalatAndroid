package com.example.salat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        SettingsStore.init(context)
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED &&
            SettingsStore.getBool(context, "enabled", false)) {
            val service = Intent(context, ReminderService::class.java).setAction(ReminderService.ACTION_START)
            try { ContextCompat.startForegroundService(context, service) } catch (_: Exception) { }
        }
    }
}
