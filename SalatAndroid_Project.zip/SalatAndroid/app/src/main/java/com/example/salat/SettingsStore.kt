package com.example.salat

import android.content.Context
import android.content.SharedPreferences

object SettingsStore {
    private const val FILE = "salat_settings"
    private lateinit var p: SharedPreferences

    fun init(context: Context) {
        if (!::p.isInitialized) p = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    private fun prefs(context: Context): SharedPreferences {
        if (!::p.isInitialized) init(context)
        return p
    }

    fun getBool(c: Context, k: String, d: Boolean = false) = prefs(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { prefs(c).edit().putBoolean(k, v).apply() }
    fun getInt(c: Context, k: String, d: Int) = prefs(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) { prefs(c).edit().putInt(k, v).apply() }
    fun getLong(c: Context, k: String, d: Long) = prefs(c).getLong(k, d)
    fun putLong(c: Context, k: String, v: Long) { prefs(c).edit().putLong(k, v).apply() }
    fun getString(c: Context, k: String, d: String = "") = prefs(c).getString(k, d) ?: d
    fun putString(c: Context, k: String, v: String) { prefs(c).edit().putString(k, v).apply() }

    fun duration(c: Context, locked: Boolean): Long {
        val prefix = if (locked) "locked" else "other"
        val h = getInt(c, "${prefix}_h", if (locked) 0 else 0)
        val m = getInt(c, "${prefix}_m", if (locked) 30 else 1)
        val s = getInt(c, "${prefix}_s", 0)
        return (h * 3600L + m * 60L + s).coerceIn(1, 18000)
    }

    fun saveDuration(c: Context, locked: Boolean, h: Int, m: Int, s: Int) {
        val prefix = if (locked) "locked" else "other"
        prefs(c).edit().putInt("${prefix}_h", h).putInt("${prefix}_m", m)
            .putInt("${prefix}_s", s).apply()
    }
}
