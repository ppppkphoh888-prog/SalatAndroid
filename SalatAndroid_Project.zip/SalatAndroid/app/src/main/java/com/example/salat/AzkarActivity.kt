package com.example.salat

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.*

class AzkarActivity : Activity() {
    private val white = 0xFFFFFFFF.toInt()
    private val gold = 0xFFD9B25A.toInt()
    private val green = 0xFF0B2A21.toInt()
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SettingsStore.init(this)
        AzkarStore.ensure(this)
        render()
    }

    private fun render() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(16, 16, 16, 24)
            setBackgroundColor(green)
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = "الأذكار"; textSize = 26f; setTextColor(gold); gravity = Gravity.CENTER
        })
        count = TextView(this).apply { setTextColor(white); textSize = 16f }
        root.addView(count)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        button(root, "إضافة عدة أذكار / استيراد") { multiDialog() }
        button(root, "تصدير الأذكار") { export() }
        button(root, "نسخ الأذكار") { copy() }
        input = EditText(this).apply {
            hint = "اكتب ذكرًا جديدًا"; setTextColor(white); setHintTextColor(0xFFBBBBBB.toInt())
            minLines = 2; gravity = Gravity.TOP or Gravity.RIGHT
        }
        root.addView(input)
        button(root, "إضافة") {
            val value = input.text.toString().trim()
            val items = AzkarStore.read(this)
            when {
                value.isBlank() -> Toast.makeText(this, "اكتب الذكر أولًا", Toast.LENGTH_SHORT).show()
                items.size >= 100 -> Toast.makeText(this, "وصلت إلى الحد الأقصى: ١٠٠ ذكر", Toast.LENGTH_SHORT).show()
                items.any { it.text == value } -> Toast.makeText(this, "هذا الذكر موجود مسبقًا", Toast.LENGTH_SHORT).show()
                else -> {
                    items.add(Dhikr(true, value)); AzkarStore.save(this, items)
                    input.text.clear(); render()
                }
            }
        }
        renderRows()
    }

    private fun renderRows() {
        list.removeAllViews()
        val items = AzkarStore.read(this)
        count.text = "${arabic(items.size)} / ١٠٠"
        if (items.size >= 100) {
            input.visibility = View.GONE
        } else input.visibility = View.VISIBLE
        if (items.size >= 100) {
            list.addView(TextView(this).apply { text = "وصلت للحد الأقصى من الأذكار"; setTextColor(gold) })
        }
        items.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val enabled = Switch(this).apply {
                isChecked = item.enabled
                setOnCheckedChangeListener { _, checked ->
                    val updated = AzkarStore.read(this@AzkarActivity)
                    updated[index] = updated[index].copy(enabled = checked)
                    AzkarStore.save(this@AzkarActivity, updated)
                }
            }
            row.addView(enabled)
            val label = TextView(this).apply {
                text = item.text; setTextColor(white); textSize = 15f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setPadding(8, 10, 8, 10)
                setOnClickListener { editDialog(index, item.text) }
            }
            row.addView(label)
            val delete = Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    AlertDialog.Builder(this@AzkarActivity).setTitle("حذف الذكر؟")
                        .setMessage(item.text).setNegativeButton("إلغاء", null)
                        .setPositiveButton("حذف") { _, _ ->
                            val updated = AzkarStore.read(this@AzkarActivity)
                            updated.removeAt(index); AzkarStore.save(this@AzkarActivity, updated); render()
                        }.show()
                }
            }
            row.addView(delete)
            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(0x55777777); layoutParams = LinearLayout.LayoutParams(-1, 1) })
        }
    }

    private fun editDialog(index: Int, old: String) {
        val edit = EditText(this).apply { setText(old); minLines = 3; gravity = Gravity.TOP or Gravity.RIGHT }
        AlertDialog.Builder(this).setTitle("تعديل الذكر").setView(edit)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val value = edit.text.toString().trim()
                if (value.isNotEmpty()) {
                    val items = AzkarStore.read(this)
                    items[index] = items[index].copy(text = value)
                    AzkarStore.save(this, items); render()
                }
            }.show()
    }

    private fun multiDialog() {
        val edit = EditText(this).apply {
            hint = "كل ذكر في سطر مستقل"; minLines = 8; gravity = Gravity.TOP or Gravity.RIGHT
        }
        AlertDialog.Builder(this).setTitle("إضافة عدة أذكار أو استيراد")
            .setMessage("الصق الأذكار، بحيث يكون كل ذكر في سطر. سيتم تجاهل الفارغ والمكرر.")
            .setView(edit).setNegativeButton("إلغاء", null)
            .setPositiveButton("إضافة") { _, _ ->
                val n = AzkarStore.addMany(this, edit.text.toString())
                Toast.makeText(this, "تمت إضافة ${arabic(n)} أذكار", Toast.LENGTH_LONG).show()
                render()
            }.show()
    }

    private fun export() {
        val text = AzkarStore.read(this).joinToString("\n") { it.text }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, "تصدير الأذكار"))
    }

    private fun copy() {
        val text = AzkarStore.read(this).joinToString("\n") { it.text }
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("الأذكار", text))
        Toast.makeText(this, "تم نسخ الأذكار", Toast.LENGTH_SHORT).show()
    }

    private fun button(root: LinearLayout, title: String, action: () -> Unit) {
        root.addView(Button(this).apply { text = title; setTextColor(gold); setOnClickListener { action() } })
    }

    private fun arabic(n: Int): String {
        val digits = "٠١٢٣٤٥٦٧٨٩"
        return n.toString().map { digits[it.digitToInt()] }.joinToString("")
    }
}
