package com.example.salat

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.AlertDialog
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val gold = 0xFFD9B25A.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val green = 0xFF0B2A21.toInt()
    private var status: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SettingsStore.init(this)
        AzkarStore.ensure(this)
        buildUi()
        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        ReminderService.appInForeground = true
        notifyServiceState()
        refreshStatus()
    }

    override fun onPause() {
        ReminderService.appInForeground = false
        notifyServiceState()
        super.onPause()
    }

    private fun notifyServiceState() {
        if (SettingsStore.getBool(this, "enabled", false)) {
            try { startService(Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_STATE)) } catch (_: Exception) { }
        }
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 28)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(green)
        }
        scroll.addView(root)
        setContentView(scroll)

        title("صَلِّ")
        status = text("الحالة: غير مفعّل")
        root.addView(status)
        button("ابدأ / إيقاف") { toggleService() }
        section("الجوال مقفول")
        durationControls(true)
        soundControls(true)
        vibrationControls(true)
        section("أستخدم تطبيقًا آخر")
        durationControls(false)
        soundControls(false)
        vibrationControls(false)
        section("داخل التطبيق")
        val inside = Switch(this).apply {
            text = "إيقاف التذكير مؤقتًا داخل التطبيق"
            setTextColor(white)
            isChecked = SettingsStore.getBool(this@MainActivity, "pause_inside", false)
            setOnCheckedChangeListener { _, checked ->
                SettingsStore.putBool(this@MainActivity, "pause_inside", checked); applySettings()
            }
        }
        root.addView(inside)
        section("الأذكار")
        button("فتح قائمة الأذكار") { startActivity(Intent(this, AzkarActivity::class.java)) }
        val random = Switch(this).apply {
            text = "ترتيب عشوائي (بدون تكرار قبل المرور على القائمة)"
            setTextColor(white)
            isChecked = SettingsStore.getBool(this@MainActivity, "random_order", false)
            setOnCheckedChangeListener { _, checked ->
                SettingsStore.putBool(this@MainActivity, "random_order", checked)
                SettingsStore.putString(this@MainActivity, "random_pool", "")
                applySettings()
            }
        }
        root.addView(random)
        section("ساعات الهدوء")
        val quiet = Switch(this).apply {
            text = "تفعيل ساعات الهدوء"
            setTextColor(white)
            isChecked = SettingsStore.getBool(this@MainActivity, "quiet_enabled", false)
            setOnCheckedChangeListener { _, checked ->
                SettingsStore.putBool(this@MainActivity, "quiet_enabled", checked); applySettings()
            }
        }
        root.addView(quiet)
        button("وقت البداية") { pickTime("quiet_start", 22 * 60) }
        button("وقت النهاية") { pickTime("quiet_end", 7 * 60) }
        section("البطارية والصلاحيات")
        button("طلب استثناء تحسين البطارية") {
            try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName"))) } catch (_: Exception) { }
        }
        text("لسامسونج: الإعدادات ← التطبيقات ← صَلِّ ← البطارية ← غير مقيّد. وأخرج التطبيق من قائمة التطبيقات النائمة.")
        button("طلب إذن المنبّه الدقيق") {
            if (Build.VERSION.SDK_INT >= 31) try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }
        button("حالة الصلاحيات") { showPermissions() }
        text("ملاحظة: المدد القصيرة تستهلك بطارية أكثر.")
    }

    private fun title(s: String) {
        root.addView(TextView(this).apply {
            text = s; textSize = 30f; setTextColor(gold); gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        })
    }

    private fun section(s: String) {
        root.addView(TextView(this).apply {
            text = s; textSize = 20f; setTextColor(gold); setPadding(0, 18, 0, 8)
        })
    }

    private fun text(s: String): TextView = TextView(this).apply {
        text = s; textSize = 15f; setTextColor(white); setPadding(0, 6, 0, 6)
        root.addView(this)
    }

    private fun button(s: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            text = s; setTextColor(gold); setOnClickListener { action() }
        })
    }

    private fun durationControls(locked: Boolean) {
        val p = if (locked) "locked" else "other"
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val values = listOf("h", "m", "s").map { key ->
            NumberPicker(this).apply {
                minValue = 0
                maxValue = if (key == "h") 5 else 59
                value = SettingsStore.getInt(this@MainActivity, "${p}_$key",
                    if (locked && key == "m") 30 else if (!locked && key == "m") 1 else 0)
                wrapSelectorWheel = false
                contentDescription = when (key) { "h" -> "ساعات"; "m" -> "دقائق"; else -> "ثواني" }
                layoutParams = LinearLayout.LayoutParams(0, 150, 1f)
            }
        }
        values.forEach { row.addView(it) }
        root.addView(row)
        button("حفظ مدة ${if (locked) "القفل" else "التطبيق الآخر"}") {
            val h = values[0].value; val m = values[1].value; val s = values[2].value
            val total = h * 3600 + m * 60 + s
            if (total !in 1..18000) {
                Toast.makeText(this, "المدة يجب أن تكون من ثانية واحدة إلى ٥ ساعات", Toast.LENGTH_LONG).show()
            } else {
                SettingsStore.saveDuration(this, locked, h, m, s)
                if (total < 60) Toast.makeText(this, "المدد القصيرة تستهلك بطارية أكثر", Toast.LENGTH_LONG).show()
                applySettings()
            }
        }
    }

    private fun soundControls(locked: Boolean) {
        val key = if (locked) "locked" else "other"
        val sw = Switch(this).apply {
            text = "تشغيل الصوت (${if (locked) "القفل" else "التطبيق الآخر"})"
            setTextColor(white)
            isChecked = SettingsStore.getBool(this@MainActivity, "${key}_sound", true)
            setOnCheckedChangeListener { _, b -> SettingsStore.putBool(this@MainActivity, "${key}_sound", b); applySettings() }
        }
        root.addView(sw)
        button("اختيار نغمة الإشعار") {
            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر نغمة")
            startActivityForResult(i, if (locked) 10 else 11)
        }
        button("تجربة الصوت") { playTestSound(key) }
    }

    private fun playTestSound(key: String) {
        try {
            val uri = SettingsStore.getString(this, "${key}_tone").takeIf { it.isNotBlank() }?.let(Uri::parse)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(this, uri)?.apply { play() }
        } catch (_: Exception) { Toast.makeText(this, "تعذر تشغيل النغمة", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Legacy callback used for ringtone picker compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && (requestCode == 10 || requestCode == 11)) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            if (uri != null) {
                SettingsStore.putString(this, if (requestCode == 10) "locked_tone" else "other_tone", uri.toString())
                applySettings()
            }
        }
    }

    private fun vibrationControls(locked: Boolean) {
        val key = if (locked) "locked" else "other"
        val sw = Switch(this).apply {
            text = "الاهتزاز"
            setTextColor(white)
            isChecked = SettingsStore.getBool(this@MainActivity, "${key}_vibrate", true)
            setOnCheckedChangeListener { _, b -> SettingsStore.putBool(this@MainActivity, "${key}_vibrate", b); applySettings() }
        }
        root.addView(sw)
        val seek = SeekBar(this).apply {
            max = 100
            progress = SettingsStore.getInt(this@MainActivity, "${key}_strength", 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    SettingsStore.putInt(this@MainActivity, "${key}_strength", value.coerceAtLeast(1))
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { applySettings() }
            })
        }
        root.addView(seek)
        button("تجربة الاهتزاز") {
            try {
                val v = getSystemService(VIBRATOR_SERVICE) as android.os.Vibrator
                if (Build.VERSION.SDK_INT >= 26 && v.hasAmplitudeControl())
                    v.vibrate(android.os.VibrationEffect.createOneShot(300, (seek.progress * 255 / 100).coerceIn(1, 255)))
                else {
                    Toast.makeText(this, "جهازك لا يدعم التحكم بقوة الاهتزاز؛ سيُستخدم الاهتزاز العادي", Toast.LENGTH_LONG).show()
                    @Suppress("DEPRECATION") v.vibrate(300)
                }
            } catch (_: Exception) { }
        }
    }

    private fun pickTime(key: String, default: Int) {
        val mins = SettingsStore.getInt(this, key, default)
        TimePickerDialog(this, { _, h, m ->
            SettingsStore.putInt(this, key, h * 60 + m); applySettings()
        }, mins / 60, mins % 60, false).show()
    }

    private fun toggleService() {
        if (SettingsStore.getBool(this, "enabled", false)) {
            startService(Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_STOP))
        } else {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
                return
            }
            SettingsStore.putBool(this, "enabled", true)
            try { ContextCompat.startForegroundService(this, Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_START)) }
            catch (_: Exception) { SettingsStore.putBool(this, "enabled", false); Toast.makeText(this, "تعذر تشغيل الخدمة", Toast.LENGTH_LONG).show() }
        }
        refreshStatus()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 90 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) toggleService()
    }

    private fun applySettings() {
        if (SettingsStore.getBool(this, "enabled", false)) {
            try { startService(Intent(this, ReminderService::class.java).setAction(ReminderService.ACTION_REFRESH)) }
            catch (_: Exception) { }
        }
        refreshStatus()
    }

    private fun refreshStatus() {
        status?.text = if (SettingsStore.getBool(this, "enabled", false))
            "الحالة: مفعّل • ${if (ReminderService.appInForeground) "داخل التطبيق" else "خارج التطبيق"}"
        else "الحالة: متوقف"
    }

    private fun showPermissions() {
        val exact = Build.VERSION.SDK_INT < 31 || (getSystemService(ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
        val battery = (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
        val notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        AlertDialog.Builder(this).setTitle("حالة الصلاحيات")
            .setMessage("الإشعارات: ${mark(notif)}\nالمنبّه الدقيق: ${mark(exact)}\nاستثناء البطارية: ${mark(battery)}")
            .setPositiveButton("حسنًا", null).show()
    }

    private fun mark(b: Boolean) = if (b) "✓" else "✗"
}
