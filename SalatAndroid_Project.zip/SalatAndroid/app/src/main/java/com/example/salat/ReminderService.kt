package com.example.salat

import android.app.*
import android.content.*
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import android.app.KeyguardManager
import android.app.PowerManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Calendar

class ReminderService : Service() {
    companion object {
        const val ACTION_START = "com.example.salat.START"
        const val ACTION_STOP = "com.example.salat.STOP"
        const val ACTION_FIRE = "com.example.salat.FIRE"
        const val ACTION_STATE = "com.example.salat.STATE"
        const val ACTION_REFRESH = "com.example.salat.REFRESH"
        const val CHANNEL = "salat_reminders"
        const val NOTIFICATION_ID = 71
        @Volatile var appInForeground = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var receiverRegistered = false
    private var ringtone: Ringtone? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var shortRunnable: Runnable? = null
    private var currentState = "مقفول"
    private var reminderCount = 0
    private lateinit var alarm: AlarmManager

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateStateAndSchedule()
        }
    }

    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        alarm = getSystemService(ALARM_SERVICE) as AlarmManager
        createChannel()
        registerScreenReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopEverything(); return START_NOT_STICKY }
            ACTION_FIRE -> { fireReminder(); return START_STICKY }
            ACTION_STATE -> { updateStateAndSchedule(); return START_STICKY }
            ACTION_REFRESH -> {
                currentState = when {
                    isLocked() -> "مقفول"
                    appInForeground -> "داخل التطبيق"
                    else -> "تطبيق آخر"
                }
                cancelSchedule()
                scheduleNext()
                updatePersistentNotification()
                return START_STICKY
            }
            else -> {
                startForeground(NOTIFICATION_ID, buildPersistentNotification())
                updateStateAndSchedule()
            }
        }
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        receiverRegistered = true
    }

    private fun isLocked(): Boolean {
        val power = getSystemService(POWER_SERVICE) as PowerManager
        val keyguard = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        return keyguard.isKeyguardLocked || !power.isInteractive
    }

    private fun updateStateAndSchedule() {
        val next = when {
            isLocked() -> "مقفول"
            appInForeground -> "داخل التطبيق"
            else -> "تطبيق آخر"
        }
        if (next != currentState) {
            currentState = next
            cancelSchedule()
            scheduleNext()
        } else if (shortRunnable == null && !hasAlarm()) {
            scheduleNext()
        }
        updatePersistentNotification()
    }

    private fun durationForState(): Long {
        return when (currentState) {
            "مقفول" -> SettingsStore.duration(this, true)
            else -> if (currentState == "داخل التطبيق" &&
                SettingsStore.getBool(this, "pause_inside", false)) 0L
            else SettingsStore.duration(this, false)
        }
    }

    private fun scheduleNext() {
        val duration = durationForState()
        if (duration <= 0L) return
        val now = System.currentTimeMillis()
        val target = if (isQuietNow()) now else now + duration * 1000L
        val whenAt = quietEndIfNeeded(target)
        val delay = (whenAt - now).coerceAtLeast(1000L)
        if (delay < 60_000L) {
            acquireWakeLock()
            shortRunnable = Runnable {
                releaseWakeLock()
                shortRunnable = null
                fireReminder()
            }
            handler.postDelayed(shortRunnable!!, delay)
        } else {
            val pi = alarmPendingIntent()
            try {
                if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) {
                    try {
                        val request = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        request.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        startActivity(request)
                    } catch (_: Exception) { }
                    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
                } else {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi)
                }
            } catch (_: Exception) {
                try { alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt, pi) } catch (_: Exception) { }
            }
        }
    }

    private fun quietEndIfNeeded(target: Long): Long {
        if (!SettingsStore.getBool(this, "quiet_enabled", false)) return target
        val start = SettingsStore.getInt(this, "quiet_start", 22 * 60)
        val end = SettingsStore.getInt(this, "quiet_end", 7 * 60)
        val cal = Calendar.getInstance().apply { timeInMillis = target }
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val quiet = if (start < end) now in start until end else now >= start || now < end
        if (!quiet) return target
        val endCal = Calendar.getInstance().apply {
            timeInMillis = target
            set(Calendar.HOUR_OF_DAY, end / 60)
            set(Calendar.MINUTE, end % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (start >= end && now >= start) add(Calendar.DAY_OF_YEAR, 1)
        }
        return endCal.timeInMillis.coerceAtLeast(target + 1000)
    }

    private fun fireReminder() {
        if (!SettingsStore.getBool(this, "enabled", false)) return
        if (isQuietNow()) {
            cancelSchedule()
            scheduleNext()
            return
        }
        val (text, ordinal) = AzkarStore.current(this)
        reminderCount++
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("تذكير")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSubText(ordinal)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setTimeoutAfter(6000)
            .setContentIntent(PendingIntent.getActivity(this, 2,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            .build()
        try { getSystemService(NotificationManager::class.java).notify(100 + reminderCount, n) } catch (_: Exception) { }
        playConfiguredSound()
        vibrateConfigured()
        updatePersistentNotification()
        cancelSchedule()
        scheduleNext()
    }

    private fun isQuietNow(): Boolean {
        if (!SettingsStore.getBool(this, "quiet_enabled", false)) return false
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val s = SettingsStore.getInt(this, "quiet_start", 22 * 60)
        val e = SettingsStore.getInt(this, "quiet_end", 7 * 60)
        return if (s < e) now in s until e else now >= s || now < e
    }

    private fun playConfiguredSound() {
        val locked = currentState == "مقفول"
        if (!SettingsStore.getBool(this, if (locked) "locked_sound" else "other_sound", true)) return
        try {
            ringtone?.stop()
            val uriText = SettingsStore.getString(this, if (locked) "locked_tone" else "other_tone")
            val uri = if (uriText.isNotBlank()) Uri.parse(uriText)
                else RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION).build()
            ringtone?.play()
        } catch (_: Exception) { }
    }

    private fun vibrateConfigured() {
        val locked = currentState == "مقفول"
        if (!SettingsStore.getBool(this, if (locked) "locked_vibrate" else "other_vibrate", true)) return
        try {
            val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
            val strength = SettingsStore.getInt(this, if (locked) "locked_strength" else "other_strength", 60)
            if (Build.VERSION.SDK_INT >= 26 && vibrator.hasAmplitudeControl()) {
                val amp = (strength * 255 / 100).coerceIn(1, 255)
                vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 350), intArrayOf(0, amp), -1))
            } else vibrator.vibrate(350)
        } catch (_: Exception) { }
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock?.isHeld == true) return
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Salat:Reminder").apply {
                setReferenceCounted(false)
                acquire(60_000L)
            }
        } catch (_: Exception) { }
    }

    private fun releaseWakeLock() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
    }

    private fun alarmPendingIntent(): PendingIntent =
        PendingIntent.getService(this, 44, Intent(this, ReminderService::class.java).setAction(ACTION_FIRE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun hasAlarm(): Boolean = PendingIntent.getService(this, 44,
        Intent(this, ReminderService::class.java).setAction(ACTION_FIRE),
        PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) != null

    private fun cancelSchedule() {
        shortRunnable?.let { handler.removeCallbacks(it) }
        shortRunnable = null
        releaseWakeLock()
        try { alarm.cancel(alarmPendingIntent()) } catch (_: Exception) { }
    }

    private fun createChannel() {
        val channel = NotificationChannel(CHANNEL, "تذكيرات الذكر", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false)
            description = "إشعار تذكير دائم وإشعارات الأذكار"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildPersistentNotification(): Notification {
        val stop = PendingIntent.getService(this, 45,
            Intent(this, ReminderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("صَلِّ • التذكير مفعّل")
            .setContentText("الحالة: $currentState • المدة: ${durationForState()} ث • التذكيرات: $reminderCount")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stop)
            .build()
    }

    private fun updatePersistentNotification() {
        try { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildPersistentNotification()) }
        catch (_: Exception) { }
    }

    private fun stopEverything() {
        SettingsStore.putBool(this, "enabled", false)
        cancelSchedule()
        try { ringtone?.stop() } catch (_: Exception) { }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cancelSchedule()
        try { ringtone?.stop() } catch (_: Exception) { }
        if (receiverRegistered) {
            try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
