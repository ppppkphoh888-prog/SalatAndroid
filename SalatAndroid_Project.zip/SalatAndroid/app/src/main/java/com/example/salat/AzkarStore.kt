package com.example.salat

import android.content.Context
import java.io.File

data class Dhikr(val enabled: Boolean, val text: String)

object AzkarStore {
    private const val FILE = "azkar.txt"
    private val defaults = listOf(
        "اللهم صلِّ وسلِّم على سيدنا محمد",
        "اللهم صلِّ على سيدنا محمد وعلى آله وصحبه وسلم",
        "اللهم صلِّ وسلم وبارك على سيدنا محمد",
        "صلى الله على سيدنا محمد وعلى آله وصحبه وسلم",
        "اللهم صلِّ صلاة كاملة وسلم سلامًا تامًا على سيدنا محمد",
        "سبحان الله وبحمده سبحان الله العظيم",
        "أستغفر الله العظيم وأتوب إليه",
        "لا إله إلا الله وحده لا شريك له",
        "اللهم أعنّي على ذكرك وشكرك وحسن عبادتك",
        "اللهم صلِّ على محمد النبي الأمي وعلى آله وسلم"
    )

    private fun file(c: Context) = File(c.filesDir, FILE)

    fun ensure(c: Context) {
        if (!file(c).exists()) save(c, defaults.map { Dhikr(true, it) })
    }

    fun read(c: Context): MutableList<Dhikr> {
        ensure(c)
        return try {
            file(c).readLines().mapNotNull {
                val split = it.split('|', limit = 2)
                if (split.size == 2 && split[1].isNotBlank()) Dhikr(split[0] == "1", split[1]) else null
            }.take(100).toMutableList()
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(c: Context, items: List<Dhikr>) {
        file(c).writeText(items.take(100).joinToString("\n") {
            "${if (it.enabled) 1 else 0}|${it.text.replace("\n", " ").trim()}"
        })
    }

    fun addMany(c: Context, text: String): Int {
        val items = read(c)
        val known = items.map { it.text.trim() }.toMutableSet()
        var added = 0
        text.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach {
            if (items.size < 100 && known.add(it)) {
                items.add(Dhikr(true, it))
                added++
            }
        }
        save(c, items)
        return added
    }

    fun current(c: Context): Pair<String, String> {
        val all = read(c)
        val active = all.filter { it.enabled }
        if (active.isEmpty()) return "اللهم صلِّ وسلِّم على سيدنا محمد" to "ذكر افتراضي"
        val random = SettingsStore.getBool(c, "random_order", false)
        val order = if (random) {
            val pool = SettingsStore.getString(c, "random_pool", "").split(",").mapNotNull { it.toIntOrNull() }
                .filter { it in active.indices }.toMutableList()
            var last = SettingsStore.getInt(c, "last_random", -1)
            if (pool.isEmpty()) {
                pool.addAll(active.indices)
                pool.shuffle()
                if (pool.size > 1 && pool.first() == last) pool.add(pool.removeAt(0))
            }
            val index = pool.removeAt(0)
            SettingsStore.putString(c, "random_pool", pool.joinToString(","))
            SettingsStore.putInt(c, "last_random", index)
            active[index]
        } else {
            val pos = SettingsStore.getInt(c, "seq_pos", 0).mod(active.size)
            SettingsStore.putInt(c, "seq_pos", (pos + 1) % active.size)
            active[pos]
        }
        val ordinal = active.indexOf(order) + 1
        return order.text to "ذكر $ordinal من ${active.size}"
    }
}
